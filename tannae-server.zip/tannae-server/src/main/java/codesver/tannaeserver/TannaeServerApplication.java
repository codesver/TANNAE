package codesver.tannaeserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TannaeServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TannaeServerApplication.class, args);
	}

}
