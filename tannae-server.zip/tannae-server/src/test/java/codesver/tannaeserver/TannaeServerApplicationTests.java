package codesver.tannaeserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TannaeServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
